// Main menu, match setup, and end-of-match banner. Pure DOM overlay;
// calls back into main.js via the supplied callbacks.
import { sfx, setAudioVolume as setVol, setAudioMuted as setMuted } from './audio.js';
import { frameForFaction, drawFrame } from './display.js';
import {
  loadSettings, saveSettings, loadRecords,
} from './settings.js';
const PERSONALITIES = ['Front', 'Sky', 'Raid', 'Fortress'];
const DIFFICULTIES = ['recruit', 'veteran', 'elite', 'marshal'];
// (smoke harness inlines all modules into one scope: no const shared with hud.js)
const MENU_PASSIVE_ABILITIES = ['edge_network', 'integrated_sky', 'siha_mesh', 'iron_layer'];
// active abilities gated behind a standing structure (mirrors sim ABILITY_STRUCT)
const ABILITY_GATE_TEXT = {
  saka_insertion: 'needs Sa\'ka Tent',
  shahed_rain: 'needs Drone Workshop',
  brahmos_lane: 'needs Cruise Battery',
  rsaf_tasking: 'needs Green Crescent',
  babur_window: 'needs Ghaznavi Rain',
};

// one-liner under a faction button: econ perk + ability
function perkLine(f) {
  const parts = [];
  const pk = f.econPerk;
  if (pk) {
    const pct = Math.round(Math.abs(pk.value) * 100);
    switch (pk.type) {
      case 'cheap_cy_rebuild': parts.push('−' + pct + '% CY rebuild'); break;
      case 'oil_income_mult': parts.push('+' + Math.round((pk.value - 1) * 100) + '% oil'); break;
      case 'early_build_speed':
        parts.push('+' + pct + '% build speed first ' + Math.round(pk.until_s / 60) + 'min');
        break;
      case 'war_factory_discount': parts.push('−' + pct + '% vehicle cost'); break;
      case 'unit_build_speed': parts.push('+' + pct + '% ' + pk.unit_name + ' build'); break;
      default: parts.push(pk.type.replace(/_/g, ' '));
    }
  }
  if (f.ability) {
    const ab = f.ability.replace(/_/g, ' ');
    parts.push(MENU_PASSIVE_ABILITIES.includes(f.ability) ? ab + ' (passive)'
      : ABILITY_GATE_TEXT[f.ability] ? ab + ' (' + ABILITY_GATE_TEXT[f.ability] + ')' : ab);
  }
  return parts.join(' · ');
}

function h(tag, cls, text) {
  const el = document.createElement(tag);
  if (cls) el.className = cls;
  if (text !== undefined) el.textContent = text;
  return el;
}

// button that clicks with a sound
function btn(cls, text) {
  const b = h('button', cls, text);
  b.addEventListener('click', () => sfx('ui'));
  return b;
}

// small faction emblem from the atlas next to the color swatch (best effort)
function emblemCanvas(game, faction, size) {
  const c = document.createElement('canvas');
  c.width = size; c.height = size;
  c.style.width = size + 'px';
  c.style.height = size + 'px';
  c.style.imageRendering = 'auto';
  try {
    const ctx2 = c.getContext('2d');
    const frame = frameForFaction(faction);
    if (!drawFrame(ctx2, game.atlas, frame, 0, 0, size, size)) {
      // fallback: faction color diamond
      const col = (game.data.factions[faction] || {}).color || '#888';
      ctx2.fillStyle = col;
      ctx2.save();
      ctx2.translate(size / 2, size / 2);
      ctx2.rotate(Math.PI / 4);
      ctx2.fillRect(-size * 0.28, -size * 0.28, size * 0.56, size * 0.56);
      ctx2.restore();
    }
  } catch (e) { /* emblem is decorative */ }
  return c;
}

export function showMenu(game, onStart) {
  game._onStart = onStart;
  game.overlay = 'menu';
  game.resumePause = null;
  game.menuBack = null;
  if (document.body && document.body.classList) document.body.classList.add('in-menu');
  // hide any lingering in-match floaters
  const tt = document.getElementById('tooltip');
  if (tt) tt.style.display = 'none';
  const cl = document.getElementById('cursor-label');
  if (cl && cl.classList) cl.classList.remove('flash');
  const root = document.getElementById('menu');
  root.classList.remove('hidden');
  root.innerHTML = '';
  const box = h('div', 'menu-box title-box');
  const title = h('h1', 'game-title', 'MCA');
  box.appendChild(title);
  box.appendChild(h('p', 'game-sub', 'Middle East Combat Arena — modern skirmish RTS'));

  const row1 = h('div', 'menu-row title-row');
  const start = btn('menu-btn primary', '▶  Skirmish');
  start.addEventListener('click', () => showSetup(game, root, onStart));
  const how = btn('menu-btn', 'How to Play');
  how.addEventListener('click', () => showHowTo(game, root));
  const set = btn('menu-btn', 'Settings');
  set.addEventListener('click', () => showSettings(game, root));
  row1.appendChild(start); row1.appendChild(how); row1.appendChild(set);
  box.appendChild(row1);

  // service record
  const rec = loadRecords();
  const recLine = h('div', 'records-line');
  if (rec.wins + rec.losses > 0) {
    const fac = Object.entries(rec.byFaction)
      .map(([f, r2]) => f + ' ' + r2.w + 'W/' + r2.l + 'L').join(' · ');
    recLine.textContent = 'Service record: ' + rec.wins + 'W / ' + rec.losses + 'L'
      + (fac ? '  —  ' + fac : '');
    if (rec.lastMatch && rec.lastMatch.stats) {
      const s = rec.lastMatch.stats;
      recLine.textContent += '  ·  last: ' + (rec.lastMatch.won ? 'victory' : 'defeat')
        + ' in ' + fmtDur(s.ticks) + ', ' + s.unitsBuilt + ' built';
    }
  } else {
    recLine.textContent = 'No matches on record — deploy your MCV, commander.';
  }
  box.appendChild(recLine);
  root.appendChild(box);
  const banner = document.getElementById('banner');
  banner.classList.add('hidden');
}

function fmtDur(ticks) {
  const s = Math.floor(ticks / 10);
  return Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0');
}

// ---- How to Play ---------------------------------------------------------------

function showHowTo(game, root) {
  game.overlay = 'setup'; // Esc goes Back, same as setup
  root.innerHTML = '';
  const box = h('div', 'menu-box');
  box.appendChild(h('h1', null, 'How to Play'));
  const sections = [
    ['Objective', 'Destroy every enemy Construction Yard (or all their builders). Lose yours and you are out — one ConYard rebuild is allowed.'],
    ['Camera', 'Arrow keys / screen edges / middle-mouse drag to pan · mouse wheel to zoom · Space centers the selection · Home jumps to your base.'],
    ['Deploy', 'Your MCV deploys into the Construction Yard: select it, press D (or double-click it). Build power first, then an Oil Depot on an oil field for income.'],
    ['Build & train', 'Build bar at the bottom (hotkeys Q W E R T F G, Tab for next page). Structures queue, then place them green-lit on the map. Right-click a tile cancels queue; right-click the map sets rally points.'],
    ['Orders', 'Left-click select, drag box-select, Shift adds. Right-click = move / attack / capture (Engineers). A = attack-move, S = stop. Ctrl+1..9 assign control groups, 1..9 recall.'],
    ['Intel', 'Fog of war is live: scout with cheap units. Minimap pings mark finished structures and base under attack. Hover anything for a full tooltip.'],
    ['Faction ability', 'Each faction has a signature ability (some passive, some need their unique structure) plus a superweapon — buttons sit right of the build bar.'],
  ];
  for (const [t2, d] of sections) {
    box.appendChild(h('h2', null, t2));
    box.appendChild(h('p', 'howto-line', d));
  }
  const back = btn('menu-btn', 'Back');
  const goBack = () => showMenu(game, game._onStart || ((c) => {}));
  game.menuBack = goBack;
  back.addEventListener('click', goBack);
  box.appendChild(back);
  root.appendChild(box);
}

// ---- Settings --------------------------------------------------------------------

function showSettings(game, root) {
  game.overlay = 'setup';
  root.innerHTML = '';
  const box = h('div', 'menu-box');
  box.appendChild(h('h1', null, 'Settings'));
  const s = game.settings || loadSettings();

  function row(labelText, input) {
    const r = h('div', 'menu-row setting-row');
    r.appendChild(h('span', 'setting-label', labelText));
    r.appendChild(input);
    box.appendChild(r);
  }
  function persist() { saveSettings(s); if (game.settings) Object.assign(game.settings, s); }

  const vol = document.createElement('input');
  vol.type = 'range'; vol.min = '0'; vol.max = '100'; vol.value = String(Math.round(s.volume * 100));
  const volVal = h('span', 'setting-val', vol.value + '%');
  vol.addEventListener('input', () => {
    s.volume = Number(vol.value) / 100;
    volVal.textContent = vol.value + '%';
    persist();
    setVol(s.volume);
  });
  const volRow = h('div', 'menu-row setting-row');
  volRow.appendChild(h('span', 'setting-label', 'Volume'));
  volRow.appendChild(vol); volRow.appendChild(volVal);
  box.appendChild(volRow);

  const mute = document.createElement('input');
  mute.type = 'checkbox'; mute.checked = !!s.muted;
  mute.addEventListener('change', () => { s.muted = mute.checked; persist(); setMuted(s.muted); });
  row('Mute all audio', mute);

  const shake = document.createElement('input');
  shake.type = 'checkbox'; shake.checked = s.screenShake !== false;
  shake.addEventListener('change', () => { s.screenShake = shake.checked; persist(); });
  row('Screen shake', shake);

  const hints = document.createElement('input');
  hints.type = 'checkbox'; hints.checked = s.showHints !== false;
  hints.addEventListener('change', () => { s.showHints = hints.checked; persist(); });
  row('Hint banners', hints);

  const back = btn('menu-btn', 'Back');
  const goBack = () => showMenu(game, game._onStart || ((c) => {}));
  game.menuBack = goBack;
  back.addEventListener('click', goBack);
  box.appendChild(back);
  root.appendChild(box);
}

function selectEl(options, value) {
  const sel = document.createElement('select');
  for (const o of options) {
    const opt = document.createElement('option');
    opt.value = o;
    opt.textContent = o;
    if (o === value) opt.selected = true;
    sel.appendChild(opt);
  }
  return sel;
}

function showSetup(game, root, onStart) {
  game.overlay = 'setup';
  root.innerHTML = '';
  const box = h('div', 'menu-box');
  box.appendChild(h('h1', null, 'Skirmish setup'));

  const cfg = {
    map: Object.keys(game.maps)[0],
    faction: 'Egypt',
    opponents: [{ faction: 'Algeria', personality: 'Front', difficulty: 'recruit' }],
    ally: null,
  };

  // map
  box.appendChild(h('h2', null, 'Map'));
  const mapRow = h('div', 'menu-row');
  const mapBtns = {};
  for (const m of Object.keys(game.maps)) {
    const md = game.maps[m];
    const desc = (md.name || m) + ' — ' + md.w + '×' + md.h
      + ', up to ' + md.spawns.length + ' players';
    const b = h('button', 'menu-btn' + (cfg.map === m ? ' sel' : ''), desc);
    b.addEventListener('click', () => {
      cfg.map = m;
      for (const k in mapBtns) mapBtns[k].classList.toggle('sel', k === m);
      refreshOpponents();
    });
    mapBtns[m] = b;
    mapRow.appendChild(b);
  }
  box.appendChild(mapRow);

  // your faction
  box.appendChild(h('h2', null, 'Your faction'));
  const facRow = h('div', 'menu-row');
  const facBtns = {};
  for (const fname of Object.keys(game.data.factions)) {
    const f = game.data.factions[fname];
    const b = btn('menu-btn fac-btn' + (cfg.faction === fname ? ' sel' : ''));
    b.appendChild(emblemCanvas(game, fname, 22));
    b.appendChild(document.createTextNode(fname));
    b.appendChild(h('span', 'ident', f.identity || ''));
    const pl = perkLine(f);
    if (pl) b.appendChild(h('span', 'perk', pl));
    b.addEventListener('click', () => {
      cfg.faction = fname;
      for (const k in facBtns) facBtns[k].classList.toggle('sel', k === fname);
    });
    facBtns[fname] = b;
    facRow.appendChild(b);
  }
  box.appendChild(facRow);

  // AI opponents
  box.appendChild(h('h2', null, 'AI opponents'));
  const oppBox = h('div');
  box.appendChild(oppBox);

  // ally
  box.appendChild(h('h2', null, 'AI ally (team 2v2)'));
  const allyCheck = document.createElement('input');
  allyCheck.type = 'checkbox';
  allyCheck.addEventListener('change', () => {
    cfg.ally = allyCheck.checked
      ? { faction: 'Saudi', personality: 'Fortress', difficulty: 'recruit' }
      : null;
    refreshOpponents();
  });
  box.appendChild(allyCheck);
  const allyBox = h('div');
  box.appendChild(allyBox);

  function aiRow(entry, factions) {
    const row = h('div', 'menu-row');
    const fSel = selectEl(factions, entry.faction);
    fSel.addEventListener('change', () => { entry.faction = fSel.value; });
    const pSel = selectEl(PERSONALITIES, entry.personality);
    pSel.addEventListener('change', () => { entry.personality = pSel.value; });
    const dSel = selectEl(DIFFICULTIES, entry.difficulty);
    dSel.addEventListener('change', () => { entry.difficulty = dSel.value; });
    row.appendChild(fSel); row.appendChild(pSel); row.appendChild(dSel);
    return row;
  }

  function refreshOpponents() {
    const spawns = game.maps[cfg.map].spawns.length;
    // free player count: you + 1..(spawns-1) AI, optional ally if room
    if (cfg.ally && spawns < 3) { cfg.ally = null; allyCheck.checked = false; }
    const maxOpp = spawns - 1 - (cfg.ally ? 1 : 0);
    while (cfg.opponents.length > maxOpp) cfg.opponents.pop();
    while (cfg.opponents.length < 1) {
      cfg.opponents.push({ faction: 'Iran', personality: 'Front', difficulty: 'recruit' });
    }
    oppBox.innerHTML = '';
    const factions = Object.keys(game.data.factions);
    cfg.opponents.forEach((o) => oppBox.appendChild(aiRow(o, factions)));
    if (maxOpp >= 2) {
      const add = h('button', 'menu-btn', '+ Add opponent (' + cfg.opponents.length + '/' + maxOpp + ')');
      add.addEventListener('click', () => {
        if (cfg.opponents.length < maxOpp) {
          cfg.opponents.push({ faction: 'Turkey', personality: 'Sky', difficulty: 'recruit' });
          refreshOpponents();
        }
      });
      const rem = h('button', 'menu-btn', '− Remove');
      rem.addEventListener('click', () => {
        if (cfg.opponents.length > 1) {
          cfg.opponents.pop();
          refreshOpponents();
        }
      });
      oppBox.appendChild(add); oppBox.appendChild(rem);
    }
    allyCheck.disabled = spawns < 3;
    allyBox.innerHTML = '';
    if (cfg.ally) allyBox.appendChild(aiRow(cfg.ally, factions));
  }
  refreshOpponents();

  // start
  const row = h('div', 'menu-row');
  const start = btn('menu-btn start', 'Start match');
  start.addEventListener('click', () => {
    root.classList.add('hidden');
    onStart(cfg);
  });
  const back = btn('menu-btn', 'Back');
  const goBack = () => showMenu(game, onStart);
  game.menuBack = goBack; // Esc on the setup screen goes Back
  back.addEventListener('click', goBack);
  row.appendChild(start); row.appendChild(back);
  box.appendChild(row);
  root.appendChild(box);
}

// pause overlay during a live match (top-bar Menu button): Resume / Restart /
// Abandon (two-step confirm)
export function showPauseMenu(game, opts) {
  game.overlay = 'pause';
  if (document.body && document.body.classList) document.body.classList.add('in-menu');
  const root = document.getElementById('menu');
  root.classList.remove('hidden');
  root.innerHTML = '';
  const box = h('div', 'menu-box');
  box.appendChild(h('h1', null, 'Paused'));
  const row = h('div', 'menu-row');
  const resume = btn('menu-btn start', 'Resume');
  const doResume = () => {
    root.classList.add('hidden');
    if (document.body && document.body.classList) document.body.classList.remove('in-menu');
    game.resumePause = null;
    opts.onResume();
  };
  resume.addEventListener('click', doResume);
  game.resumePause = doResume; // Esc == Resume while this overlay is up
  const restart = btn('menu-btn', 'Restart');
  restart.addEventListener('click', () => {
    root.classList.add('hidden');
    opts.onRestart();
  });
  const abandon = btn('menu-btn', 'Abandon match');
  let armed = false;
  abandon.addEventListener('click', () => {
    if (!armed) {
      armed = true;
      abandon.textContent = 'Really abandon?';
      abandon.classList.add('sel');
      return;
    }
    root.classList.add('hidden');
    opts.onAbandon();
  });
  row.appendChild(resume); row.appendChild(restart); row.appendChild(abandon);
  box.appendChild(row);
  root.appendChild(box);
}

export function showEndBanner(game, opts) {
  const banner = document.getElementById('banner');
  banner.classList.remove('hidden');
  banner.className = opts.won ? 'won' : 'lost';
  banner.innerHTML = '';
  const box = h('div', 'menu-box');
  box.appendChild(h('h1', null, opts.won ? 'VICTORY' : 'DEFEAT'));
  if (opts.stats) {
    const s = opts.stats;
    const grid = h('div', 'aar-grid');
    const cells = [
      ['Match time', fmtDur(s.ticks)],
      ['Units built', s.unitsBuilt],
      ['Units lost', s.unitsLost],
      ['Structures lost', s.structsLost],
      ['Confirmed kills', s.kills],
      ['Credits banked', Math.floor(s.credits)],
    ];
    for (const [label, val] of cells) {
      const cell = h('div', 'aar-cell');
      cell.appendChild(h('div', 'aar-val', String(val)));
      cell.appendChild(h('div', 'aar-label', label));
      grid.appendChild(cell);
    }
    box.appendChild(grid);
  }
  const row = h('div', 'menu-row');
  const again = btn('menu-btn start', 'Restart');
  again.addEventListener('click', () => {
    banner.classList.add('hidden');
    opts.onRestart();
  });
  const menu = btn('menu-btn', 'Menu');
  menu.addEventListener('click', () => {
    banner.classList.add('hidden');
    opts.onMenu();
  });
  row.appendChild(again); row.appendChild(menu);
  box.appendChild(row);
  banner.appendChild(box);
}
